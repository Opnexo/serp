"""Tests for serp-resources."""
