"""
In-Memory Event Bus implementation for testing and development.

This adapter provides synchronous in-process event dispatch without
any external dependencies. Perfect for unit tests and local development.
"""

import asyncio
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Callable, Type, Optional, Awaitable

from ..domain.base_event import DomainEvent
from ..ports.event_bus import IEventBus, EventHandler


@dataclass
class InMemoryEventBus(IEventBus):
    """
    In-memory implementation of IEventBus for testing.
    
    Features:
    - Synchronous event dispatch (immediate delivery)
    - No persistence (events lost on restart)
    - No consumer groups (all handlers receive all events)
    - Perfect for unit testing and development
    
    Example:
        event_bus = InMemoryEventBus()
        
        # Subscribe
        async def on_order_created(event: OrderCreatedEvent):
            print(f"Order {event.order_id} created")
        
        event_bus.subscribe(OrderCreatedEvent, on_order_created)
        
        # Publish
        await event_bus.publish(OrderCreatedEvent(order_id=uuid4()))
        
        # For testing - access published events
        assert len(event_bus.published_events) == 1
    """
    
    _handlers: Dict[str, List[EventHandler]] = field(default_factory=lambda: defaultdict(list))
    _published_events: List[DomainEvent] = field(default_factory=list)
    _running: bool = field(default=False)
    
    @property
    def published_events(self) -> List[DomainEvent]:
        """Access published events for testing assertions."""
        return self._published_events.copy()
    
    def clear(self) -> None:
        """Clear all published events and handlers (for test cleanup)."""
        self._published_events.clear()
        self._handlers.clear()
    
    async def publish(
        self, 
        event: DomainEvent,
        stream: Optional[str] = None
    ) -> None:
        """
        Publish event and immediately dispatch to handlers.
        
        Unlike Redis/Kafka, dispatch is synchronous - handlers are
        awaited before returning.
        """
        self._published_events.append(event)
        
        event_type = event.event_type()
        handlers = self._handlers.get(event_type, [])
        
        for handler in handlers:
            try:
                await handler(event)
            except Exception as e:
                # Log but don't fail - other handlers should continue
                print(f"Handler error for {event_type}: {e}")
    
    async def publish_many(
        self, 
        events: List[DomainEvent],
        stream: Optional[str] = None
    ) -> None:
        """Publish multiple events sequentially."""
        for event in events:
            await self.publish(event, stream)
    
    def subscribe(
        self,
        event_type: Type[DomainEvent],
        handler: EventHandler,
        group: Optional[str] = None  # Ignored in memory implementation
    ) -> None:
        """Register a handler for an event type."""
        type_name = event_type.event_type()
        self._handlers[type_name].append(handler)
    
    async def start(self) -> None:
        """
        Start the event bus.
        
        In-memory implementation has nothing to start since
        dispatch is synchronous.
        """
        self._running = True
        print("📡 InMemoryEventBus started")
    
    async def stop(self) -> None:
        """Stop the event bus."""
        self._running = False
        print("📡 InMemoryEventBus stopped")
    
    async def health_check(self) -> bool:
        """Always healthy - no external dependencies."""
        return True
    
    def get_handler_count(self, event_type: Type[DomainEvent]) -> int:
        """Get number of handlers for an event type (for testing)."""
        return len(self._handlers.get(event_type.event_type(), []))
