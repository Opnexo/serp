"""
SERP Event-Driven Architecture

This module provides the event bus infrastructure for inter-module communication.

Structure:
- domain/: Base event classes (DomainEvent, EventMetadata)
- ports/: Interfaces (IEventBus, IEventPublisher, IEventSubscriber)
- adapters/: Technology implementations (Redis, Kafka, InMemory)

Usage:
    from serp_core.events import IEventBus, DomainEvent, EventMetadata
    from serp_core.events.adapters import RedisEventBus, InMemoryEventBus
"""

from .domain.base_event import DomainEvent, EventMetadata
from .domain.event_envelope import EventEnvelope
from .ports.event_bus import IEventBus
from .ports.event_publisher import IEventPublisher
from .ports.event_subscriber import IEventSubscriber

__all__ = [
    # Domain
    "DomainEvent",
    "EventMetadata",
    "EventEnvelope",
    # Ports
    "IEventBus",
    "IEventPublisher",
    "IEventSubscriber",
]
