"""
Base domain event classes for SERP event-driven architecture.

All module events MUST inherit from DomainEvent.
"""

from abc import ABC
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional
from uuid import UUID, uuid4
import re


@dataclass(frozen=True)
class EventMetadata:
    """
    Metadata attached to every domain event.
    
    Provides traceability and correlation across the system.
    
    Attributes:
        event_id: Unique identifier for this event instance
        timestamp: When the event occurred
        correlation_id: Links related events in a flow (e.g., all events from one request)
        causation_id: The event that caused this one (for event chains)
        user_id: Who triggered the action that caused this event
        version: Event schema version for backward compatibility
    """
    event_id: UUID = field(default_factory=uuid4)
    timestamp: datetime = field(default_factory=datetime.utcnow)
    correlation_id: Optional[UUID] = None
    causation_id: Optional[UUID] = None
    user_id: Optional[UUID] = None
    version: str = "1.0"


@dataclass(kw_only=True)
class DomainEvent(ABC):
    """
    Base class for all domain events in SERP.
    
    All module events MUST inherit from this class.
    Events are immutable records of something that happened.
    
    Naming Convention:
    - Past tense (InvoiceCreated, not CreateInvoice)
    - Descriptive of the business action
    
    Note: Uses kw_only=True to allow child classes to have required fields
    while this base class has metadata with a default value.
    
    Example:
        @dataclass(kw_only=True)
        class CustomerCreatedEvent(DomainEvent):
            customer_id: UUID
            email: str
            name: str
            
            @classmethod
            def event_type(cls) -> str:
                return "users.customer.created"
        
        # Usage:
        event = CustomerCreatedEvent(
            customer_id=uuid4(),
            email="john@example.com",
            name="John Doe"
        )
    """
    metadata: EventMetadata = field(default_factory=EventMetadata)
    
    @classmethod
    def event_type(cls) -> str:
        """
        Returns the unique event type identifier.
        
        Convention: {module}.{aggregate}.{action}
        Example: "invoicing.invoice.created"
        
        Override in subclasses for custom naming.
        Default converts CamelCase class name to dot.notation.
        """
        name = cls.__name__
        # Remove 'Event' suffix if present
        if name.endswith('Event'):
            name = name[:-5]
        # Convert CamelCase to dot.notation
        return re.sub(r'(?<!^)(?=[A-Z])', '.', name).lower()
    
    @classmethod
    def stream_name(cls) -> str:
        """
        Returns the stream/topic name for routing.
        
        Default: First part of event_type (module name) + "-events".
        Override for custom routing strategies.
        
        Example: "invoicing.invoice.created" -> "invoicing-events"
        """
        return cls.event_type().split('.')[0] + "-events"
    
    def with_correlation(self, correlation_id: UUID) -> "DomainEvent":
        """
        Create a new event with the given correlation ID.
        
        Useful when publishing events within a chain of operations.
        """
        new_metadata = EventMetadata(
            event_id=self.metadata.event_id,
            timestamp=self.metadata.timestamp,
            correlation_id=correlation_id,
            causation_id=self.metadata.causation_id,
            user_id=self.metadata.user_id,
            version=self.metadata.version,
        )
        # Shallow copy with new metadata
        import copy
        new_event = copy.copy(self)
        object.__setattr__(new_event, 'metadata', new_metadata)
        return new_event
