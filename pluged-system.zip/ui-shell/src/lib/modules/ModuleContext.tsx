'use client';

import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { ModuleRegistry, LoadedModule } from '@/types';
import { moduleRegistry } from './registry';
import { moduleLoader } from './loader';

interface ModuleContextType {
    modules: ModuleRegistry[];
    loadedModules: LoadedModule[];
    isLoading: boolean;
    loadModule: (moduleId: string) => Promise<void>;
    loadModules: (moduleIds: string[]) => Promise<void>;
}

const ModuleContext = createContext<ModuleContextType | undefined>(undefined);

export function ModuleProvider({ children }: { children: React.ReactNode }) {
    const [modules, setModules] = useState<ModuleRegistry[]>([]);
    const [loadedModules, setLoadedModules] = useState<LoadedModule[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    /**
     * Load initial modules from backend API
     */
    useEffect(() => {
        const initModules = async () => {
            try {
                console.log('🔵 ModuleContext: Starting to load modules from API...');

                // Fetch and register all modules from backend
                const loaded = await moduleLoader.loadFromAPI();

                console.log('🟢 ModuleContext: Loaded modules:', loaded);
                console.log('🟢 ModuleContext: Registry modules:', moduleRegistry.getSorted());

                setModules(moduleRegistry.getSorted());
                setLoadedModules(loaded);
            } catch (error) {
                console.error('🔴 ModuleContext: Failed to load modules:', error);
            } finally {
                setIsLoading(false);
                console.log('🟡 ModuleContext: Loading complete');
            }
        };

        initModules();
    }, []);

    /**
     * Load a single module
     */
    const loadModule = useCallback(async (moduleId: string) => {
        try {
            await moduleLoader.load(moduleId);
            setModules(moduleRegistry.getSorted());
            setLoadedModules(moduleLoader.getAll());
        } catch (error) {
            console.error(`Failed to load module ${moduleId}:`, error);
        }
    }, []);

    /**
     * Load multiple modules
     */
    const loadModules = useCallback(async (moduleIds: string[]) => {
        try {
            await moduleLoader.loadMany(moduleIds);
            setModules(moduleRegistry.getSorted());
            setLoadedModules(moduleLoader.getAll());
        } catch (error) {
            console.error('Failed to load modules:', error);
        }
    }, []);

    const value: ModuleContextType = {
        modules,
        loadedModules,
        isLoading,
        loadModule,
        loadModules,
    };

    return (
        <ModuleContext.Provider value={value}>{children}</ModuleContext.Provider>
    );
}

/**
 * Hook to access module context
 */
export function useModules() {
    const context = useContext(ModuleContext);
    if (context === undefined) {
        throw new Error('useModules must be used within a ModuleProvider');
    }
    return context;
}
