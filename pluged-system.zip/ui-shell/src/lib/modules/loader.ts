import type { ModuleRegistry, LoadedModule } from '@/types';
import { moduleRegistry } from './registry';
import { componentRegistry } from './componentRegistry';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

/**
 * Module loader
 *
 * Handles the complete module loading flow:
 * 1. Fetches UI configurations from /api/ui-config
 * 2. Loads JavaScript bundles from /api/modules/{id}/bundle.js
 * 3. Registers components in the global component registry
 */
class ModuleLoaderClass {
    // Use window-based state to persist across Next.js navigations
    private get loadedModules(): Map<string, LoadedModule> {
        if (typeof window !== 'undefined') {
            if (!(window as any).__SERP_LOADED_MODULES__) {
                (window as any).__SERP_LOADED_MODULES__ = new Map<string, LoadedModule>();
            }
            return (window as any).__SERP_LOADED_MODULES__;
        }
        return new Map();
    }

    private get bundleLoadPromises(): Map<string, Promise<boolean>> {
        if (typeof window !== 'undefined') {
            if (!(window as any).__SERP_BUNDLE_LOAD_PROMISES__) {
                (window as any).__SERP_BUNDLE_LOAD_PROMISES__ = new Map<string, Promise<boolean>>();
            }
            return (window as any).__SERP_BUNDLE_LOAD_PROMISES__;
        }
        return new Map();
    }

    /**
     * Discover and load all modules from backend API
     */
    async loadFromAPI(): Promise<LoadedModule[]> {
        try {
            console.log('🔵 ModuleLoader: Fetching from', `${API_BASE_URL}/api/ui-config`);

            const response = await fetch(`${API_BASE_URL}/api/ui-config`);

            console.log('🟡 ModuleLoader: Response status:', response.status);

            if (!response.ok) {
                throw new Error(`Failed to fetch UI config: ${response.statusText}`);
            }

            const configs = await response.json();
            console.log('🟢 ModuleLoader: Received configs:', configs);

            const loadedModules: LoadedModule[] = [];

            // Register each module config and load its bundle
            for (const [moduleId, config] of Object.entries(configs)) {
                console.log(`🔵 ModuleLoader: Registering module: ${moduleId}`);

                const registry = config as ModuleRegistry;

                // Register with the global registry
                moduleRegistry.register(registry);

                const loaded: LoadedModule = {
                    ...registry,
                    loaded: true,
                };

                this.loadedModules.set(moduleId, loaded);
                loadedModules.push(loaded);

                // Load the module's JavaScript bundle in the background
                this.loadModuleBundle(moduleId);

                console.log(`🟢 ModuleLoader: Module ${moduleId} registered successfully`);
            }

            console.log('🟢 ModuleLoader: All modules loaded:', loadedModules.length);
            return loadedModules;
        } catch (error) {
            console.error('🔴 ModuleLoader: Error loading modules from API:', error);
            return [];
        }
    }

    /**
     * Load a module's JavaScript bundle
     */
    async loadModuleBundle(moduleId: string): Promise<boolean> {
        console.log(`📦 ModuleLoader.loadModuleBundle('${moduleId}') called`);

        // Check if already loading
        if (this.bundleLoadPromises.has(moduleId)) {
            console.log(`📦 ModuleLoader: Bundle for '${moduleId}' already loading, awaiting...`);
            return this.bundleLoadPromises.get(moduleId)!;
        }

        // Check if already loaded in component registry
        if (componentRegistry.has(moduleId)) {
            console.log(`📦 ModuleLoader: Bundle for '${moduleId}' already in registry`);
            return true;
        }

        console.log(`📦 ModuleLoader: Starting fresh load for '${moduleId}'`);
        const loadPromise = this._loadBundle(moduleId);
        this.bundleLoadPromises.set(moduleId, loadPromise);

        try {
            const result = await loadPromise;
            console.log(`📦 ModuleLoader: Load for '${moduleId}' completed with result: ${result}`);
            return result;
        } finally {
            this.bundleLoadPromises.delete(moduleId);
        }
    }

    /**
     * Internal: Load a module bundle
     */
    private async _loadBundle(moduleId: string): Promise<boolean> {
        try {
            const bundle = await componentRegistry.loadModule(moduleId);
            return bundle !== null;
        } catch (error) {
            console.error(`🔴 ModuleLoader: Failed to load bundle for ${moduleId}:`, error);
            return false;
        }
    }

    /**
     * Ensure a module's bundle is loaded before rendering
     */
    async ensureBundleLoaded(moduleId: string): Promise<boolean> {
        console.log(`📦 ModuleLoader.ensureBundleLoaded('${moduleId}') called`);
        if (componentRegistry.has(moduleId)) {
            console.log(`📦 ModuleLoader.ensureBundleLoaded('${moduleId}') - already loaded, returning true`);
            return true;
        }
        console.log(`📦 ModuleLoader.ensureBundleLoaded('${moduleId}') - not loaded, calling loadModuleBundle`);
        const result = await this.loadModuleBundle(moduleId);
        console.log(`📦 ModuleLoader.ensureBundleLoaded('${moduleId}') - loadModuleBundle returned: ${result}`);
        return result;
    }

    /**
     * Load a module dynamically (kept for backward compatibility)
     */
    async load(moduleId: string): Promise<LoadedModule> {
        // Check if already loaded
        const cached = this.loadedModules.get(moduleId);
        if (cached) {
            // Ensure bundle is also loaded
            await this.ensureBundleLoaded(moduleId);
            return cached;
        }

        try {
            // Fetch specific module config from API
            const response = await fetch(`${API_BASE_URL}/api/ui-config/${moduleId}`);

            if (!response.ok) {
                throw new Error(`Module ${moduleId} not found`);
            }

            const config = await response.json();

            if (config.error) {
                throw new Error(config.error);
            }

            const registry: ModuleRegistry = config;

            // Register the module
            moduleRegistry.register(registry);

            // Load the bundle
            await this.loadModuleBundle(moduleId);

            const loaded: LoadedModule = {
                ...registry,
                loaded: true,
            };

            this.loadedModules.set(moduleId, loaded);
            return loaded;
        } catch (error) {
            const errorModule: LoadedModule = {
                moduleId,
                moduleName: moduleId,
                version: '0.0.0',
                icon: 'AlertCircle',
                ribbon: {
                    tabId: moduleId,
                    tabLabel: moduleId,
                    tabIcon: 'AlertCircle',
                    tabOrder: 999,
                    groups: [],
                },
                routes: [],
                permissions: [],
                loaded: false,
                error: error as Error,
            };

            this.loadedModules.set(moduleId, errorModule);
            return errorModule;
        }
    }

    /**
     * Load multiple modules
     */
    async loadMany(moduleIds: string[]): Promise<LoadedModule[]> {
        return Promise.all(moduleIds.map((id) => this.load(id)));
    }

    /**
     * Get loaded module
     */
    get(moduleId: string): LoadedModule | undefined {
        return this.loadedModules.get(moduleId);
    }

    /**
     * Get all loaded modules
     */
    getAll(): LoadedModule[] {
        return Array.from(this.loadedModules.values());
    }

    /**
     * Check if module is loaded
     */
    isLoaded(moduleId: string): boolean {
        return this.loadedModules.has(moduleId);
    }

    /**
     * Check if module bundle is loaded
     */
    isBundleLoaded(moduleId: string): boolean {
        return componentRegistry.has(moduleId);
    }

    /**
     * Unload a module
     */
    unload(moduleId: string): boolean {
        moduleRegistry.unregister(moduleId);
        return this.loadedModules.delete(moduleId);
    }
}

export const moduleLoader = new ModuleLoaderClass();
