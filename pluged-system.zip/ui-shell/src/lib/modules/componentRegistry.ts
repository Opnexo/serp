/**
 * Global Component Registry
 *
 * This registry allows module bundles to register their components
 * at runtime. The shell uses this registry to render module views.
 *
 * Flow:
 * 1. Shell fetches /api/ui-config → gets module configs with route definitions
 * 2. Shell fetches /api/modules/{id}/bundle.js → loads module JS bundle
 * 3. Bundle executes and calls registry.register() to register its components
 * 4. Shell renders routes using components from the registry
 */

import { ComponentType } from 'react';

export interface ModuleComponents {
    [componentName: string]: ComponentType<any>;
}

export interface ModuleBundle {
    MODULE_ID: string;
    MODULE_NAME: string;
    MODULE_VERSION: string;
    components: {
        [name: string]: () => Promise<{ default: ComponentType<any> }>;
    };
    getComponent: (name: string) => (() => Promise<{ default: ComponentType<any> }>) | undefined;
}

type RegistrationCallback = (moduleId: string, bundle: ModuleBundle) => void;

class ComponentRegistryClass {
    private modules: Map<string, ModuleBundle> = new Map();
    private loadingPromises: Map<string, Promise<ModuleBundle | null>> = new Map();
    private callbacks: RegistrationCallback[] = [];

    /**
     * Register a module bundle
     * Called by module bundles when they are loaded
     */
    register(moduleId: string, bundle: ModuleBundle): void {
        console.log(`📦 ComponentRegistry: Registering module '${moduleId}'`);
        console.log(`📦 ComponentRegistry: bundle value:`, bundle);
        console.log(`📦 ComponentRegistry: bundle type:`, typeof bundle);
        console.log(`📦 ComponentRegistry: bundle is undefined?`, bundle === undefined);
        console.log(`📦 ComponentRegistry: bundle is null?`, bundle === null);

        if (bundle === undefined || bundle === null) {
            console.error(`📦 ComponentRegistry: WARNING - attempting to register undefined/null bundle for '${moduleId}'`);
            console.trace('Stack trace for undefined bundle registration:');
        }

        this.modules.set(moduleId, bundle);

        // Notify listeners
        this.callbacks.forEach((cb) => cb(moduleId, bundle));
    }

    /**
     * Get a registered module bundle
     */
    get(moduleId: string): ModuleBundle | undefined {
        return this.modules.get(moduleId);
    }

    /**
     * Check if a module is registered
     */
    has(moduleId: string): boolean {
        const result = this.modules.has(moduleId);
        console.log(`🔍 ComponentRegistry.has('${moduleId}') = ${result}, modules size = ${this.modules.size}`);
        return result;
    }

    /**
     * Get a component loader from a module
     */
    getComponent(
        moduleId: string,
        componentName: string
    ): (() => Promise<{ default: ComponentType<any> }>) | undefined {
        console.log(`🔍 ComponentRegistry.getComponent('${moduleId}', '${componentName}')`);
        console.log(`🔍 this.modules is:`, this.modules);
        console.log(`🔍 this.modules.constructor.name:`, this.modules?.constructor?.name);
        console.log(`🔍 Available modules:`, Array.from(this.modules.keys()));
        console.log(`🔍 Checking for key '${moduleId}', type: ${typeof moduleId}`);

        // Try iterating to see what's actually in there
        this.modules.forEach((value, key) => {
            console.log(`🔍 Map entry: key='${key}' (type: ${typeof key}), value=`, value);
        });

        const bundle = this.modules.get(moduleId);
        console.log(`🔍 this.modules.get('${moduleId}') returned:`, bundle);

        if (!bundle) {
            console.warn(`ComponentRegistry: Module '${moduleId}' not found`);
            console.warn(`ComponentRegistry: this.modules size = ${this.modules.size}`);
            return undefined;
        }

        console.log(`🔍 Bundle found:`, bundle);
        console.log(`🔍 Bundle.components:`, bundle.components ? Object.keys(bundle.components) : 'undefined');

        const loader = bundle.components?.[componentName] || bundle.getComponent?.(componentName);
        if (!loader) {
            console.warn(
                `ComponentRegistry: Component '${componentName}' not found in module '${moduleId}'`
            );
            return undefined;
        }

        return loader;
    }

    /**
     * Get all registered module IDs
     */
    getModuleIds(): string[] {
        return Array.from(this.modules.keys());
    }

    /**
     * Subscribe to module registration events
     */
    onRegister(callback: RegistrationCallback): () => void {
        this.callbacks.push(callback);
        return () => {
            const index = this.callbacks.indexOf(callback);
            if (index > -1) {
                this.callbacks.splice(index, 1);
            }
        };
    }

    /**
     * Load a module bundle from the API
     */
    async loadModule(moduleId: string): Promise<ModuleBundle | null> {
        // Already loaded?
        if (this.modules.has(moduleId)) {
            return this.modules.get(moduleId)!;
        }

        // Already loading?
        if (this.loadingPromises.has(moduleId)) {
            return this.loadingPromises.get(moduleId)!;
        }

        const loadPromise = this._loadModuleBundle(moduleId);
        this.loadingPromises.set(moduleId, loadPromise);

        try {
            const result = await loadPromise;
            return result;
        } finally {
            this.loadingPromises.delete(moduleId);
        }
    }

    /**
     * Internal: Load and execute a module bundle
     */
    private async _loadModuleBundle(moduleId: string): Promise<ModuleBundle | null> {
        const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
        const bundleUrl = `${apiUrl}/api/modules/${moduleId}/bundle.js`;

        console.log(`📦 ComponentRegistry: Loading bundle for '${moduleId}' from ${bundleUrl}`);

        try {
            const response = await fetch(bundleUrl);

            if (!response.ok) {
                console.error(
                    `Failed to load bundle for '${moduleId}': ${response.status} ${response.statusText}`
                );
                return null;
            }

            const code = await response.text();

            // Execute the bundle in a way that it can register itself
            // The bundle is an IIFE that sets window.SerpXxxModule
            // and then auto-registers via the footer in vite.config.ts
            const executeBundle = new Function(code);
            executeBundle();

            // The bundle should have registered itself
            if (this.modules.has(moduleId)) {
                console.log(`✅ ComponentRegistry: Module '${moduleId}' loaded successfully`);
                return this.modules.get(moduleId)!;
            }

            // Fallback: try to get from window
            const windowKey = `Serp${moduleId.charAt(0).toUpperCase() + moduleId.slice(1)}Module`;
            const windowBundle = (window as any)[windowKey];

            if (windowBundle) {
                this.register(moduleId, windowBundle);
                return windowBundle;
            }

            console.error(`Module '${moduleId}' did not register itself after loading`);
            return null;
        } catch (error) {
            console.error(`Error loading module '${moduleId}':`, error);
            return null;
        }
    }

    /**
     * Load multiple modules
     */
    async loadModules(moduleIds: string[]): Promise<Map<string, ModuleBundle | null>> {
        const results = new Map<string, ModuleBundle | null>();

        await Promise.all(
            moduleIds.map(async (id) => {
                const bundle = await this.loadModule(id);
                results.set(id, bundle);
            })
        );

        return results;
    }
}

// Use window global as the source of truth to ensure consistency across Next.js navigation
// This prevents the issue where module-level singletons may be recreated
function getRegistry(): ComponentRegistryClass {
    if (typeof window !== 'undefined') {
        // Check if registry already exists on window
        if (!(window as any).__SERP_MODULE_REGISTRY__) {
            console.log('🆕 Creating new ComponentRegistryClass on window');
            (window as any).__SERP_MODULE_REGISTRY__ = new ComponentRegistryClass();
        }
        const registry = (window as any).__SERP_MODULE_REGISTRY__;
        console.log(`📍 getRegistry() returning registry with ${registry.getModuleIds?.()?.length ?? 'unknown'} modules`);
        return registry;
    }
    // Server-side: return a new instance (won't be used for actual component loading)
    console.log('⚠️ getRegistry() called on server side, creating temporary instance');
    return new ComponentRegistryClass();
}

// Create a proxy that always delegates to the window-based registry
// This ensures that even if the module is re-imported, we always use the same registry
const registryProxy: ComponentRegistryClass = {
    register(moduleId: string, bundle: ModuleBundle) {
        console.log(`🔄 Proxy.register('${moduleId}') -> getRegistry()`);
        return getRegistry().register(moduleId, bundle);
    },
    get(moduleId: string) {
        return getRegistry().get(moduleId);
    },
    has(moduleId: string) {
        console.log(`🔄 Proxy.has('${moduleId}') -> getRegistry()`);
        return getRegistry().has(moduleId);
    },
    getComponent(moduleId: string, componentName: string) {
        console.log(`🔄 Proxy.getComponent('${moduleId}', '${componentName}') -> getRegistry()`);
        return getRegistry().getComponent(moduleId, componentName);
    },
    getModuleIds() {
        return getRegistry().getModuleIds();
    },
    onRegister(callback: RegistrationCallback) {
        return getRegistry().onRegister(callback);
    },
    loadModule(moduleId: string) {
        console.log(`🔄 Proxy.loadModule('${moduleId}') -> getRegistry()`);
        return getRegistry().loadModule(moduleId);
    },
    loadModules(moduleIds: string[]) {
        return getRegistry().loadModules(moduleIds);
    },
} as ComponentRegistryClass;

// Export the proxy as the singleton
export const componentRegistry = registryProxy;

// Re-export getRegistry for cases where direct access is needed
export { getRegistry };
