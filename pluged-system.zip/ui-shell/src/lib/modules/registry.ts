import type { ModuleRegistry, LoadedModule } from '@/types';

/**
 * Module registry
 * Modules register themselves at runtime
 */
class ModuleRegistryClass {
    // Use window-based state to persist across Next.js navigations
    private get modules(): Map<string, ModuleRegistry> {
        if (typeof window !== 'undefined') {
            if (!(window as any).__SERP_MODULE_REGISTRY_DATA__) {
                (window as any).__SERP_MODULE_REGISTRY_DATA__ = new Map<string, ModuleRegistry>();
            }
            return (window as any).__SERP_MODULE_REGISTRY_DATA__;
        }
        return new Map();
    }

    /**
     * Register a module
     */
    register(module: ModuleRegistry): void {
        if (this.modules.has(module.moduleId)) {
            console.warn(`Module ${module.moduleId} is already registered`);
            return;
        }
        this.modules.set(module.moduleId, module);
    }

    /**
     * Get a module by ID
     */
    get(moduleId: string): ModuleRegistry | undefined {
        return this.modules.get(moduleId);
    }

    /**
     * Get all registered modules
     */
    getAll(): ModuleRegistry[] {
        return Array.from(this.modules.values());
    }

    /**
     * Check if a module is registered
     */
    has(moduleId: string): boolean {
        return this.modules.has(moduleId);
    }

    /**
     * Unregister a module
     */
    unregister(moduleId: string): boolean {
        return this.modules.delete(moduleId);
    }

    /**
     * Get modules sorted by ribbon tab order
     */
    getSorted(): ModuleRegistry[] {
        return this.getAll().sort(
            (a, b) => a.ribbon.tabOrder - b.ribbon.tabOrder
        );
    }
}

export const moduleRegistry = new ModuleRegistryClass();
