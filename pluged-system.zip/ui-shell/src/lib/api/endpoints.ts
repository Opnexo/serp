/**
 * API endpoints for SERP backend
 */

export const endpoints = {
    // Authentication
    auth: {
        login: '/api/auth/login',
        logout: '/api/auth/logout',
        refresh: '/api/auth/refresh',
        me: '/api/auth/me',
    },

    // Users
    users: {
        list: '/api/users',
        detail: (id: string) => `/api/users/${id}`,
        create: '/api/users',
        update: (id: string) => `/api/users/${id}`,
        delete: (id: string) => `/api/users/${id}`,
        permissions: (id: string) => `/api/users/${id}/permissions`,
    },

    // Modules
    modules: {
        list: '/api/modules',
        detail: (id: string) => `/api/modules/${id}`,
        routes: '/api/modules/routes',
        permissions: '/api/modules/permissions',
    },

    // Health
    health: '/api/health',
} as const;
