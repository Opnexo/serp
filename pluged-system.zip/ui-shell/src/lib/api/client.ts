import axios, { AxiosError, AxiosInstance, AxiosRequestConfig } from 'axios';
import type { ApiResponse, ApiError } from '@/types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
const API_TIMEOUT = Number(process.env.NEXT_PUBLIC_API_TIMEOUT) || 30000;
const AUTH_STORAGE_KEY =
    process.env.NEXT_PUBLIC_AUTH_STORAGE_KEY || 'serp_auth_token';

/**
 * Create axios instance with default config
 */
export const apiClient: AxiosInstance = axios.create({
    baseURL: API_URL,
    timeout: API_TIMEOUT,
    headers: {
        'Content-Type': 'application/json',
    },
});

/**
 * Request interceptor - Add auth token
 */
apiClient.interceptors.request.use(
    (config) => {
        if (typeof window !== 'undefined') {
            const token = localStorage.getItem(AUTH_STORAGE_KEY);
            if (token) {
                config.headers.Authorization = `Bearer ${token}`;
            }
        }
        return config;
    },
    (error) => Promise.reject(error)
);

/**
 * Response interceptor - Handle errors
 */
apiClient.interceptors.response.use(
    (response) => response,
    async (error: AxiosError<ApiError>) => {
        // Handle 401 - Unauthorized
        if (error.response?.status === 401) {
            if (typeof window !== 'undefined') {
                localStorage.removeItem(AUTH_STORAGE_KEY);
                window.location.href = '/login';
            }
        }

        // Transform error to ApiError format
        const apiError: ApiError = {
            message: error.response?.data?.message || error.message || 'An error occurred',
            code: error.response?.data?.code || error.code,
            status: error.response?.status,
            details: error.response?.data?.details,
        };

        return Promise.reject(apiError);
    }
);

/**
 * Helper to extract data from response
 * Handles both wrapped { data: ... } and direct responses
 */
function extractData<T>(responseData: any): T {
    // If response has a 'data' wrapper, unwrap it
    if (responseData && typeof responseData === 'object' && 'data' in responseData) {
        return responseData.data;
    }
    // Otherwise return as-is
    return responseData;
}

/**
 * Generic GET request
 */
export async function get<T>(
    url: string,
    config?: AxiosRequestConfig
): Promise<T> {
    const response = await apiClient.get<T>(url, config);
    return extractData<T>(response.data);
}

/**
 * Generic POST request
 */
export async function post<T>(
    url: string,
    data?: any,
    config?: AxiosRequestConfig
): Promise<T> {
    const response = await apiClient.post<T>(url, data, config);
    return extractData<T>(response.data);
}

/**
 * Generic PUT request
 */
export async function put<T>(
    url: string,
    data?: any,
    config?: AxiosRequestConfig
): Promise<T> {
    const response = await apiClient.put<T>(url, data, config);
    return extractData<T>(response.data);
}

/**
 * Generic PATCH request
 */
export async function patch<T>(
    url: string,
    data?: any,
    config?: AxiosRequestConfig
): Promise<T> {
    const response = await apiClient.patch<T>(url, data, config);
    return extractData<T>(response.data);
}

/**
 * Generic DELETE request
 */
export async function del<T>(
    url: string,
    config?: AxiosRequestConfig
): Promise<T> {
    const response = await apiClient.delete<T>(url, config);
    return extractData<T>(response.data);
}

/**
 * Set auth token
 */
export function setAuthToken(token: string): void {
    if (typeof window !== 'undefined') {
        localStorage.setItem(AUTH_STORAGE_KEY, token);
    }
}

/**
 * Get auth token
 */
export function getAuthToken(): string | null {
    if (typeof window !== 'undefined') {
        return localStorage.getItem(AUTH_STORAGE_KEY);
    }
    return null;
}

/**
 * Remove auth token
 */
export function removeAuthToken(): void {
    if (typeof window !== 'undefined') {
        localStorage.removeItem(AUTH_STORAGE_KEY);
    }
}
