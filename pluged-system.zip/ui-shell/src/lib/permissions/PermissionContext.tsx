'use client';

import { createContext, useContext, useMemo } from 'react';
import { useAuth } from '@/lib/auth';
import type { PermissionState } from '@/types';

// Development mode: bypass permission checks
// Set NEXT_PUBLIC_DEV_BYPASS_PERMISSIONS=true to bypass in dev
const DEV_BYPASS = typeof window !== 'undefined' &&
    (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1');

interface PermissionContextType extends PermissionState {
    hasPermission: (permission: string) => boolean;
    hasAnyPermission: (permissions: string[]) => boolean;
    hasAllPermissions: (permissions: string[]) => boolean;
}

const PermissionContext = createContext<PermissionContextType | undefined>(
    undefined
);

export function PermissionProvider({ children }: { children: React.ReactNode }) {
    const { user, isLoading } = useAuth();

    const permissions = useMemo(() => user?.permissions || [], [user]);

    /**
     * Check if user has a specific permission
     * In dev mode, always returns true for easier development
     */
    const hasPermission = (permission: string): boolean => {
        if (DEV_BYPASS) return true;
        return permissions.includes(permission);
    };

    /**
     * Check if user has any of the specified permissions
     */
    const hasAnyPermission = (requiredPermissions: string[]): boolean => {
        if (DEV_BYPASS) return true;
        return requiredPermissions.some((p) => permissions.includes(p));
    };

    /**
     * Check if user has all of the specified permissions
     */
    const hasAllPermissions = (requiredPermissions: string[]): boolean => {
        if (DEV_BYPASS) return true;
        return requiredPermissions.every((p) => permissions.includes(p));
    };

    const value: PermissionContextType = {
        permissions,
        isLoading,
        hasPermission,
        hasAnyPermission,
        hasAllPermissions,
    };

    return (
        <PermissionContext.Provider value={value}>
            {children}
        </PermissionContext.Provider>
    );
}

/**
 * Hook to access permission context
 */
export function usePermissions() {
    const context = useContext(PermissionContext);
    if (context === undefined) {
        throw new Error('usePermissions must be used within a PermissionProvider');
    }
    return context;
}
