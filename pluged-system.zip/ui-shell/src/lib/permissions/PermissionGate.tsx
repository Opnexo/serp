'use client';

import { usePermissions } from './PermissionContext';

interface PermissionGateProps {
    permission?: string;
    permissions?: string[];
    requireAll?: boolean;
    fallback?: React.ReactNode;
    children: React.ReactNode;
}

/**
 * Component to conditionally render based on permissions
 */
export function PermissionGate({
    permission,
    permissions,
    requireAll = false,
    fallback = null,
    children,
}: PermissionGateProps) {
    const { hasPermission, hasAnyPermission, hasAllPermissions } = usePermissions();

    let hasAccess = true;

    if (permission) {
        hasAccess = hasPermission(permission);
    } else if (permissions) {
        hasAccess = requireAll
            ? hasAllPermissions(permissions)
            : hasAnyPermission(permissions);
    }

    if (!hasAccess) {
        return <>{fallback}</>;
    }

    return <>{children}</>;
}
