'use client';

import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import type { User, AuthState, LoginCredentials } from '@/types';
import { post, get, setAuthToken, removeAuthToken, getAuthToken } from '@/lib/api';
import { endpoints } from '@/lib/api/endpoints';

interface AuthContextType extends AuthState {
    login: (credentials: LoginCredentials) => Promise<void>;
    logout: () => Promise<void>;
    refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
    const [state, setState] = useState<AuthState>({
        user: null,
        token: null,
        isAuthenticated: false,
        isLoading: true,
    });

    /**
     * Initialize auth state from stored token
     */
    useEffect(() => {
        const initAuth = async () => {
            const token = getAuthToken();
            if (token) {
                try {
                    const user = await get<User>(endpoints.auth.me);
                    setState({
                        user,
                        token,
                        isAuthenticated: true,
                        isLoading: false,
                    });
                } catch (error) {
                    removeAuthToken();
                    setState({
                        user: null,
                        token: null,
                        isAuthenticated: false,
                        isLoading: false,
                    });
                }
            } else {
                setState((prev) => ({ ...prev, isLoading: false }));
            }
        };

        initAuth();
    }, []);

    /**
     * Login user
     */
    const login = useCallback(async (credentials: LoginCredentials) => {
        setState((prev) => ({ ...prev, isLoading: true }));

        try {
            const response = await post<{ accessToken: string; user: User }>(
                endpoints.auth.login,
                credentials
            );

            setAuthToken(response.accessToken);
            setState({
                user: response.user,
                token: response.accessToken,
                isAuthenticated: true,
                isLoading: false,
            });
        } catch (error) {
            setState({
                user: null,
                token: null,
                isAuthenticated: false,
                isLoading: false,
            });
            throw error;
        }
    }, []);

    /**
     * Logout user
     */
    const logout = useCallback(async () => {
        try {
            await post(endpoints.auth.logout);
        } catch (error) {
            // Ignore logout errors
        } finally {
            removeAuthToken();
            setState({
                user: null,
                token: null,
                isAuthenticated: false,
                isLoading: false,
            });
        }
    }, []);

    /**
     * Refresh user data
     */
    const refreshUser = useCallback(async () => {
        if (!state.isAuthenticated) return;

        try {
            const user = await get<User>(endpoints.auth.me);
            setState((prev) => ({ ...prev, user }));
        } catch (error) {
            // If refresh fails, logout
            await logout();
        }
    }, [state.isAuthenticated, logout]);

    const value: AuthContextType = {
        ...state,
        login,
        logout,
        refreshUser,
    };

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

/**
 * Hook to access auth context
 */
export function useAuth() {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
