'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from './AuthContext';

// Development mode: bypass auth checks on localhost
const isDevBypass = () =>
    typeof window !== 'undefined' &&
    (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1');

interface AuthGuardProps {
    children: React.ReactNode;
    fallback?: React.ReactNode;
}

/**
 * Component to protect routes requiring authentication
 * In development mode (localhost), authentication is bypassed
 */
export function AuthGuard({ children, fallback }: AuthGuardProps) {
    const { isAuthenticated, isLoading } = useAuth();
    const router = useRouter();
    const [devBypass, setDevBypass] = useState(false);

    useEffect(() => {
        // Check for dev bypass on client side
        setDevBypass(isDevBypass());
    }, []);

    useEffect(() => {
        if (!isLoading && !isAuthenticated && !devBypass) {
            router.push('/login');
        }
    }, [isAuthenticated, isLoading, devBypass, router]);

    // In dev mode, bypass auth
    if (devBypass) {
        return <>{children}</>;
    }

    if (isLoading) {
        return fallback || <div>Loading...</div>;
    }

    if (!isAuthenticated) {
        return null;
    }

    return <>{children}</>;
}
