"""Tests for CRM module."""
