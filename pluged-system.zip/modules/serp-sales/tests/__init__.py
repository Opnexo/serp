"""Tests for Sales module."""
